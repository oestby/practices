#include <iostream>
#include "Image.h"
#include "Matrix.h"
//inkluder andre headerfiler du lager
using namespace std;

int main(){
//Skriv kode her
return 0;
}
